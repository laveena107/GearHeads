package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class d1 extends AppCompatActivity {


    Button k,r,z;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d1);

        k = (Button)findViewById(R.id.button2);
        r = (Button)findViewById(R.id.button3);
        z = (Button)findViewById(R.id.button4);

        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), ks1.class));

            }
        });
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), rs1.class));

            }
        });

        z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), zs1.class));

            }
        });


    }
}