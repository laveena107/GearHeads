package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class rs2 extends AppCompatActivity {

    ImageView soil,soil1,soil2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rs2);

        soil = (ImageView)findViewById(R.id.iv);
        soil1 = (ImageView)findViewById(R.id.iv1);
        soil2 = (ImageView)findViewById(R.id.iv2);


        soil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), crop221.class));

            }
        });
        soil1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), crop222.class));

            }
        });
        soil2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), crop223.class));

            }
        });
    }
}