package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class zs5 extends AppCompatActivity {

    ImageView soil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zs5);

        soil = (ImageView)findViewById(R.id.iv);

        soil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), crop1.class));

            }
        });
    }
}