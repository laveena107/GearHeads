package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class s4 extends AppCompatActivity {


    ImageView dis1,dis2,dis3,dis4,dis5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s4);
        dis1 = (ImageView)findViewById(R.id.d1);
        dis2 = (ImageView)findViewById(R.id.d2);
        dis3 = (ImageView)findViewById(R.id.d3);
        dis4 = (ImageView)findViewById(R.id.d4);
        dis5 = (ImageView)findViewById(R.id.d5);
        dis1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), d1.class));

            }
        });
        dis2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), d2.class));

            }
        });

        dis3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), d3.class));

            }
        });
        dis4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),d4.class));
            }
        });

        dis5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), d5.class));
            }
        });
    }
}