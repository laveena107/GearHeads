package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;

public class map extends AppCompatActivity {

    ImageView state1,state2,state3,state4,state5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        state1 = (ImageView)findViewById(R.id.s1);
        state2 = (ImageView)findViewById(R.id.s2);
        state3 = (ImageView)findViewById(R.id.s3);
        state4 = (ImageView)findViewById(R.id.s4);
        state5 = (ImageView)findViewById(R.id.s5);
        state1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"you selected MADHYA PRADESH", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), s1.class));

            }
        });
        state2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"you selected  UTTAR PRADESH", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), s2.class));

            }
        });

        state3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"you selected KERELA", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), s3.class));

            }
        });
        state4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"you selected MAHARASHTRA", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),s4.class));
            }
        });

        state5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"you selected WEST BENGAL", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), s5.class));
            }
        });



    }}

