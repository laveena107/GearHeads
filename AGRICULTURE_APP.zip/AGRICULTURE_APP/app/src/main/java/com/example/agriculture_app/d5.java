package com.example.agriculture_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class d5 extends AppCompatActivity {


    Button k1,r1,z1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d5);

        k1 = (Button)findViewById(R.id.button2);
        r1 = (Button)findViewById(R.id.button3);
        z1 = (Button)findViewById(R.id.button4);

        k1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), ks5.class));

            }
        });
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), rs5.class));

            }
        });

        z1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"loading...", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), zs1.class));

            }
        });


    }
}